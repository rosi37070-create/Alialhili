import os
import re
import sqlite3
import secrets
from datetime import datetime, timezone
from pathlib import Path

import qrcode
from flask import Flask, render_template, request, redirect, url_for, abort, flash
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_wtf.csrf import CSRFProtect

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("DATABASE_PATH", BASE_DIR / "certificates.sqlite3"))
app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "")
if not app.config["SECRET_KEY"]:
    raise RuntimeError("Set a strong SECRET_KEY environment variable before starting.")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024
CSRFProtect(app)
limiter = Limiter(get_remote_address, app=app, default_limits=["120 per hour"])

EVENT_TITLE = "مبادرة 55 — حب ووفاء للإمارات"
ISSUER = "مبادرة علي حسن خميس الحيلي"
DISCLAIMER = "شهادة مشاركة رمزية صادرة عن مبادرة شخصية، وليست وثيقة حكومية أو اعتماداً رسمياً."

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS certificates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                serial TEXT NOT NULL UNIQUE,
                participant_name TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.commit()

def make_serial():
    return "M55-2026-" + secrets.token_hex(5).upper()

def public_base():
    # Set PUBLIC_BASE_URL to your deployed HTTPS site, e.g. https://example.com
    return os.environ.get("PUBLIC_BASE_URL", request.url_root.rstrip("/")).rstrip("/")

@app.get("/")
def home():
    return render_template("index.html", event_title=EVENT_TITLE, issuer=ISSUER, disclaimer=DISCLAIMER)

@app.post("/issue")
@limiter.limit("5 per minute")
def issue():
    name = " ".join(request.form.get("participant_name", "").split())
    consent = request.form.get("consent")
    if not name or len(name) > 100:
        flash("يرجى إدخال اسم من 1 إلى 100 حرف.", "error")
        return redirect(url_for("home"))
    if not consent:
        flash("يرجى الموافقة على إظهار الاسم في صفحة التحقق العامة.", "error")
        return redirect(url_for("home"))

    created = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with db() as conn:
        for _ in range(5):
            serial = make_serial()
            try:
                cur = conn.execute(
                    "INSERT INTO certificates (serial, participant_name, created_at) VALUES (?, ?, ?)",
                    (serial, name, created)
                )
                conn.commit()
                cert_id = cur.lastrowid
                break
            except sqlite3.IntegrityError:
                continue
        else:
            abort(500)
    return redirect(url_for("certificate", serial=serial))

@app.get("/certificate/<serial>")
def certificate(serial):
    with db() as conn:
        cert = conn.execute("SELECT * FROM certificates WHERE serial = ?", (serial,)).fetchone()
    if cert is None:
        abort(404)
    verify_url = public_base() + url_for("verify", serial=serial)
    qr = qrcode.QRCode(box_size=7, border=2)
    qr.add_data(verify_url)
    qr.make(fit=True)
    image = qr.make_image(fill_color="#152b23", back_color="white")
    import io, base64
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    qr_data = base64.b64encode(buffer.getvalue()).decode("ascii")
    return render_template("certificate.html", cert=cert, qr_data=qr_data,
                           verify_url=verify_url, event_title=EVENT_TITLE,
                           issuer=ISSUER, disclaimer=DISCLAIMER)

@app.get("/verify/<serial>")
def verify(serial):
    with db() as conn:
        cert = conn.execute("SELECT serial, participant_name, created_at FROM certificates WHERE serial = ?", (serial,)).fetchone()
    return render_template("verify.html", cert=cert, serial=serial, disclaimer=DISCLAIMER)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Cache-Control"] = "no-store"
    return response

init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")), debug=False)
